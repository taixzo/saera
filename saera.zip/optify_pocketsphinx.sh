#!/bin/bash

mv /usr/share/pocketsphinx /opt/pocketsphinx
ln -s /opt/pocketsphinx /usr/share/pocketsphinx
